package fr.unilim.iut.refactoringExemple;

import static org.junit.Assert.*;

import org.junit.Test;

public class RefactoringExempleTest{

	@Test
	public void testShouldReturnXWhenY() {
		//assertEquals("attendu", "reel");
	}
}
