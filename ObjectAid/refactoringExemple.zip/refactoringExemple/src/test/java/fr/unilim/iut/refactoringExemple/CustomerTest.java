package fr.unilim.iut.refactoringExemple;

import static org.junit.Assert.*;

import org.junit.Test;

	public class CustomerTest {

		@Test
		public void test() {
			//assertEquals("attendu", "reel");
		}

	    
	}
